package asw1029.servlet;

import javax.servlet.*;
import java.io.*;

/**
 *
 */
public class AsyncAdapter implements AsyncListener {

    /**
     *
     * @param event
     * @throws IOException
     */
    @Override
    public void onComplete(AsyncEvent event) throws IOException {
    }

    /**
     *
     * @param event
     * @throws IOException
     */
    @Override
    public void onError(AsyncEvent event) throws IOException {
    }

    /**
     *
     * @param event
     * @throws IOException
     */
    @Override
    public void onStartAsync(AsyncEvent event) throws IOException {
    }

    /**
     *
     * @param event
     * @throws IOException
     */
    @Override
    public void onTimeout(AsyncEvent event) throws IOException {
    }
}
